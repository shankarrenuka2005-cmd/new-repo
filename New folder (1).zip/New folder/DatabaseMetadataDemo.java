import java.sql.*;

public class DatabaseMetadataDemo {
    public static void main(String[] args) throws Exception {
        try {
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/Wt_lab",
                    "root", "SpendWise@2026#");

            DatabaseMetaData dm = con.getMetaData();

            System.out.println("Database Name: " + dm.getDatabaseProductName());
            System.out.println("Database Version: " + dm.getDatabaseProductVersion());
            System.out.println("Driver Name: " + dm.getDriverName());
            System.out.println("URL: " + dm.getURL());
            System.out.println("Username: " + dm.getUserName());
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM users");
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            System.out.println("Number of Columns: " + columnCount);
            for (int i = 1; i <= columnCount; i++) {
                System.out.println(
                        "Column " + i + ": " + rsmd.getColumnName(i) + " - Type: " + rsmd.getColumnTypeName(i));
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}