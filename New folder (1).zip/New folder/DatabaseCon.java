import java.sql.*;

public class DatabaseCon {
    public static void main(String[] args) throws Exception {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wt_lab",
                "root", "password");
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("Select * from users");
        while (rs.next()) {
            System.out.println(rs.getInt("id") + rs.getString("name") +
                    rs.getInt("age") + rs.getString("course"));
        }
        st.executeUpdate("update users set age=22 where id=2");
        st.executeUpdate("delete from users where id=1");
        st.executeUpdate("insert into users values(4,'lily',22,'java')");
        rs = st.executeQuery("Select * from users");
        while (rs.next()) {
            System.out.println(rs.getInt("id") + rs.getString("name") +
                    rs.getInt("age") + rs.getString("course"));
        }
        rs.close();
        st.close();
        con.close();

    }
}
