import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class DemoServlet extends HttpServlet {
    public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws IOException {

        rs.setContentType("text/html");
        PrintWriter out = rs.getWriter();
        ServletConfig config = getServletConfig();
        ServletContext context = getServletContext();
        String student = config.getInitParameter("student");
        String college = context.getInitParameter("college");
        out.println("<h2>Servlet Parameter</h2>");
        out.println("Student Name:" + student + "<br>");
        out.println("<h2>Context Parameter</h2>");
        out.println("College Name:" + college + "<br>");
    }
}
