import java.sql.*;

public class CallableStmt {
    public static void main(String[] args) throws Exception {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wt_lab",
                "root", "password");
        PreparedStatement ps = con.prepareStatement("Insert into users (id,name,age,course) Values(?,?,?,?)");
        ps.setInt(1, 10);
        ps.setString(2, "John");
        ps.setInt(3, 20);
        ps.setString(4, "Java");
        ps.executeUpdate();
        System.out.println("Data Inserted");
        ps = con.prepareStatement("Update users set age=? where id=?");
        ps.setInt(1, 22);
        ps.setInt(2, 1);
        ps.executeUpdate();
        System.out.println("Data Updated");
        ps = con.prepareStatement("Delete from users where id=?");
        ps.setInt(1, 2);
        ps.executeUpdate();
        System.out.println("Data Deleted");
        CallableStatement cs = con.prepareCall("{call GetUsers()}");
        ResultSet rs = cs.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getInt("id") + rs.getString("name") +
                    rs.getInt("age") + rs.getString("course"));
        }
        rs.close();
        cs.close();
        ps.close();
        con.close();

    }
}
